<!DOCTYPE html>
<html lang="zxx">
<head>
    
    
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-GR7HLH2NBN"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'G-GR7HLH2NBN');
    </script>
    
    
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="description" content="Self-taught Web Developer with over two years of work experience.">
  
  <meta name="author" content="themeturn.com">

  <title>Sahil Hadke | Software Engineer</title>

  <!-- Mobile Specific Meta-->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  
  
  <!-- bootstrap.min css -->
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
  <!-- Themeify Icon Css -->
  <link rel="stylesheet" href="plugins/themify/css/themify-icons.css">
  <!-- animate.css -->
  <link rel="stylesheet" href="plugins/animate-css/animate.css">
  <link rel="stylesheet" href="plugins/aos/aos.css">
  <!-- owl carousel -->
  <link rel="stylesheet" href="plugins/owl/assets/owl.carousel.min.css">
  <link rel="stylesheet" href="plugins/owl/assets/owl.theme.default.min.css" >
  <!-- Slick slider CSS -->
  <link rel="stylesheet" href="plugins/slick-carousel/slick/slick.css">
  <link rel="stylesheet" href="plugins/slick-carousel/slick/slick-theme.css">

  <!-- Main Stylesheet -->
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">
  
  <link href="plugins/themify/cssthemify-icons.css">
  
  

</head>

<style>
    .title{
        /*text-transform:none !important;*/
        /*text-*/
    }
</style>



<body class="portfolio" id="top">


<!-- Navigation start -->
<!-- Header Start --> 

<nav class="navbar navbar-expand-lg bg-transprent py-4 fixed-top navigation" id="navbar">
	<div class="container">
	  <a class="navbar-brand" href="index.php">
	  	<h2 class="logo">Sahil</h2>
	  </a>
	  <button class="navbar-toggler" style="background-color:#000 !important;" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
		<i class="fa-solid fa-bars" style="color:#fff !important;"></i>
	  </button>
  
	  <div class="collapse navbar-collapse text-center" id="navbarsExample09">
			<ul class="navbar-nav mx-auto">
			  <li class="nav-item active">
				<a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
			  </li>
			   <li class="nav-item"><a class="nav-link smoth-scroll" href="#about">About</a></li>
			   <!--<li class="nav-item"><a class="nav-link smoth-scroll" href="#service">Services</a></li>-->
			   <li class="nav-item"><a class="nav-link smoth-scroll" href="#portfolio">portfolio</a></li>
			   <li class="nav-item"><a class="nav-link smoth-scroll" href="#contact">Contact</a></li>
			</ul>

		  	<ul class="list-inline mb-0 ml-lg-4 nav-social">
		  	    <li class="list-inline-item"><a href="mailto:sahil.hadke@gmail.com" target=_blank><i class="fa-solid fa-envelope"></i></a></li>
			  	<li class="list-inline-item"><a href="https://www.instagram.com/sahil_hadke_/" target=_blank><i class="fa-brands fa-instagram"></i></a></li>
			  	<li class="list-inline-item"><a href="https://www.linkedin.com/in/sahilhadke" target=_blank><i class="fa-brands fa-linkedin"></i></a></li>
			  	<li class="list-inline-item"><a href="https://www.github.com/sahilhadke" target=_blank><i class="fa-brands fa-github"></i></a></li>
			  	
		  	</ul>
	  </div>
	</div>
</nav>


<!-- Navigation End -->

<!-- Banner start -->

<!-- Slider Start -->
<section class="slider py-7 ">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-5 col-sm-12 col-12 col-md-5">
				<div class=" slider-img position-relative">
					<img src="images/sahil-hadke-vr.webp" alt="Sahil Hadke Potriat Image" class="animated fadeInDown img-fluid w-100">
				</div>
			</div>

			<div class="col-lg-6 col-12 col-md-7">
				<div class="ml-5 position-relative mt-5 mt-lg-0">
					<span class="head-trans">Hadke</span>
					
					<h2 class="mt-3 text-lg mb-3 text-capitalize">Sahil Hadke.</h2>
					<p class="animated fadeInUp lead mt-4 mb-5 text-white-50 lh-35">
					    
					    I’m passionate about any tech that can <span class="text-color text-md">redefine our future</span> —  If it's cutting-edge, count me in!
					    
					    
					
						
					</p>
					
					<a href="https://docs.google.com/document/d/1T3cAaLZC7_h-73AhLDCjcg_08OjIn2hg_13bfub6G_w/edit" target=_blank><button class="animated fadeInUp btn btn-main text-white" class="btn btn-hero">View Resume</button></a>
					
				
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Banner End -->

<!-- About start -->
<section class="section" id="about" data-aos="fade-up">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="row">
					<div class="col-lg-4">
						<h2>About Me</h2>
					</div>
					<div class="col-lg-8">
						
<p class="text-white-50 text-md">
My tech career initiated in India’s dynamic startup scene at <span class="text-color text-md">OG Advertising Private Limited</span>, leading website development for numerous educational institutes and prominent e-commerce platforms. This role ingrained a deep understanding of web development, user-centric design, and agile project management, setting a solid foundation for my ongoing pursuits in tech.

</p>
<p class="text-white-50 text-md">Prior to my graduate studies at <span class="text-color text-md">ASU</span>, I worked as a <span class="text-color text-md">Software Engineer at FIS Global</span>, specializing in Robotic Process Automation and Selenium. In this role, I automated complex processes, significantly enhancing operational efficiency and refining my strategic approach to tech solutions.

</p>
					</div>

				</div>
			</div>
		</div>

		
	</div>
</section>
<!-- About End -->


<section class="section" id="portfolio" data-aos="fade-up">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-8">
				<div class="section-title text-center">
					<span class="text-color mb-0 text-uppercase letter-spacing text-sm">deliver more than expected</span>
					<h2 class="title">Portfolio</h2>
				</div>
			</div>
		</div>
	</div>

	<div class="container-fluid">
		<div class="row">
			<div class="post_gallery owl-carousel owl-theme">
		    	
				
				<div class="item">
					<div class="portfolio-item position-relative">
						<img src="images/crm.webp" alt="" class="img-fluid">

						<div class="portoflio-item-overlay">
							<a ><i class="fa-solid fa-code"></i></a>
						</div>
					</div>
					<div class="text mt-3">
						<h4 class="mb-1 text-capitalize">Customer Relationship Management</h4>
						<p class="text-uppercase letter-spacing text-sm">Project</p>
					</div>
				</div>
				
				<div class="item">
					<div class="portfolio-item position-relative">
						<img src="images/jobtailor.png" alt="" class="img-fluid">

						<div class="portoflio-item-overlay">
							<a href="https://github.com/sahilhadke/job-tailor" target=_blank><i class="fa-solid fa-angle-right"></i></a>
						</div>
					</div>
					<div class="text mt-3">
						<h4 class="mb-1 text-capitalize">JobTailor</h4>
						<p class="text-uppercase letter-spacing text-sm">Project</p>
					</div>
				</div>
				
				<div class="item">
					<div class="portfolio-item position-relative">
						<img src="images/rag.png" alt="" class="img-fluid">

						<div class="portoflio-item-overlay">
							<a href="https://github.com/sahilhadke/website-rag" target=_blank><i class="fa-solid fa-angle-right"></i></a>
						</div>
					</div>
					<div class="text mt-3">
						<h4 class="mb-1 text-capitalize">RAG-based Recursive Web Crawler</h4>
						<p class="text-uppercase letter-spacing text-sm">Project</p>
					</div>
				</div>
				
				<div class="item">
					<div class="portfolio-item position-relative">
						<img src="images/pSzwtX.png" alt="" class="img-fluid">

						<div class="portoflio-item-overlay">
							<a href="https://sahil13.itch.io/dj-algo" target=_blank><i class="fa-solid fa-angle-right"></i></a>
						</div>
					</div>
					<div class="text mt-3">
						<h4 class="mb-1 text-capitalize">Dijkstra's Algorithm Visualization </h4>
						<p class="text-uppercase letter-spacing text-sm">Project</p>
					</div>
				</div>
				
				<div class="item">
					<div class="portfolio-item position-relative">
						<img src="images/cesa.webp" alt="" class="img-fluid">

						<div class="portoflio-item-overlay">
							<i class="fa-solid fa-code"></i>
						</div>
					</div>
					<div class="text mt-3">
						<h4 class="mb-1 text-capitalize">AISSMS IOIT - CESA </h4>
						<p class="text-uppercase letter-spacing text-sm">Freelance Website Development</p>
					</div>
				</div>
				<div class="item">
					<div class="portfolio-item position-relative">
						<img src="images/evergreen.webp" alt="" class="img-fluid">

						<div class="portoflio-item-overlay">
							<a href="https://evergreenpune.in/" target=_blank><i class="fa-solid fa-angle-right"></i></a>
						</div>
					</div>
					<div class="text mt-3">
						<h4 class="mb-1 text-capitalize">Evergreen Pune</h4>
						<p class="text-uppercase letter-spacing text-sm">Freelance Website Development</p>
					</div>
				</div>
				
				<div class="item">
					<div class="portfolio-item position-relative">
						<img src="images/password-manager.webp" alt="" class="img-fluid">

						<div class="portoflio-item-overlay">
							<a href="https://github.com/sahilhadke/password-manager-api" target=_blank><i class="fa-solid fa-angle-right"></i></a>
						</div>
					</div>
					<div class="text mt-3">
						<h4 class="mb-1 text-capitalize">Password Manager</h4>
						<p class="text-uppercase letter-spacing text-sm">Project</p>
					</div>
				</div>
				<div class="item">
					<div class="portfolio-item position-relative">
						<img src="images/weather-forecast.webp" alt="" class="img-fluid">

						<div class="portoflio-item-overlay">
							<a href="https://github.com/sahilhadke/weather-app" target=_blank><i class="fa-solid fa-angle-right"></i></a>
						</div>
					</div>
					<div class="text mt-3">
						<h4 class="mb-1 text-capitalize">Weather Forecast</h4>
						<p class="text-uppercase letter-spacing text-sm">Project</p>
					</div>
				</div>
				
				<div class="item">
					<div class="portfolio-item position-relative">
						<img src="images/winone.webp" alt="" class="img-fluid">

						<div class="portoflio-item-overlay">
							<i class="fa-solid fa-code"></i>
						</div>
					</div>
					<div class="text mt-3">
						<h4 class="mb-1 text-capitalize">Winone Pvt. Ltd.</h4>
						<p class="text-uppercase letter-spacing text-sm">Freelance Website Development</p>
					</div>
				</div>
				<div class="item">
					<div class="portfolio-item position-relative">
						<img src="images/cafe-brosco.webp" alt="" class="img-fluid">

						<div class="portoflio-item-overlay">
							<a href="#" target=_blank><i class="fa-solid fa-angle-right"></i></a>
						</div>
					</div>
					<div class="text mt-3">
						<h4 class="mb-1 text-capitalize">Cafe Brosco</h4>
						<p class="text-uppercase letter-spacing text-sm">Freelance Website Development</p>
					</div>
				</div>
			
				
				
			</div>
		</div>
	</div>
</section>


<!-- Contact start -->
<section class="section" id="contact" data-aos="fade-up">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-8">
				<div class="section-title text-center">
					<span class="text-color mb-0 text-uppercase letter-spacing text-sm"> your network is your net worth.</span>
					<h1 class="title">Contact</h1>
				</div>
			</div>
		</div>

		<div class="row justify-content-center">
			<div class="col-lg-8">
					<form class="contact__form form-row contact-form" method="post" action="mail.php" id="contactForm">
					 <div class="row">
                        <div class="col-12">
                            <div class="alert alert-success contact__msg" style="display: none" role="alert">
                                Your message was sent successfully.
                            </div>
                        </div>
                    </div>
					<div class="form-group col-lg-6 mb-5">
						<input type="text" id="name" name="name" class="form-control bg-transparent" placeholder="Your Name">
					</div>
					<div class="form-group col-lg-6 mb-5">
						<input type="text" name="email" id="email" class="form-control bg-transparent" placeholder="Your Email">
					</div>
				
					
					<div class="form-group col-lg-12 mb-5">
						<textarea id="message" name="message" cols="30" rows="6" class="form-control bg-transparent" placeholder="Your Message"></textarea>
						
						<div class="text-center">
							 <input class="btn btn-main text-white mt-5" id="submit" name="submit" type="submit" class="btn btn-hero" value="Send Message">
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</section>
<!-- Contact End -->

<!-- Footer start -->
<footer class="footer border-top-1">
	<div class="container">
		<div class="row align-items-center text-center text-lg-left">
			<div class="col-lg-2">
				<h2 class="logo mb-4">Sahil</h2>
			</div>

			<div class="col-lg-5">
				<ul class="list-inline footer-socials ">
					<li class="list-inline-item"><a href="https://www.instagram.com/sahil_hadke_/" target=_blank><i class="fa-brands fa-instagram"></i></a></li>
					<li class="list-inline-item"><a href="mailto:sahilhadke@gmail.com" target=_blank><i class="fa-regular fa-envelope"></i></a></li>
					
					<li class="list-inline-item"><a href="https://www.linkedin.com/in/sahilhadke" target=_blank><i class="fa-brands fa-linkedin-in"></i></a></li>
					<li class="list-inline-item"><a href="https://github.com/sahilhadke/" target=_blank><i class="fa-brands fa-github"></i></a></li>
				</ul>
			</div>
			<div class="col-lg-5">
				<p class="lead">© <span id="current-year">2022</span> All Right Reserved.</p>
				<a href="#top" class="backtop smoth-scroll"><i class="fa-solid fa-angle-up"></i></a>
			</div>
		</div>
	</div>
</footer>
<!-- Footer End -->


    <!-- 
    Essential Scripts
    =====================================-->

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- Main jQuery -->
    
    <!-- Bootstrap 4.3.1 -->
    <script src="plugins/bootstrap/js/popper.js"></script>
    <script src="plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/nav/jquery.easing.1.3.js"></script>
    
    <!-- Slick Slider -->
    <script src="plugins/slick-carousel/slick/slick.min.js"></script>
    <script src="plugins/owl/owl.carousel.min.js"></script>
  
    <!-- Skill COunt -->
    <script src="plugins/counto/apear.js"></script>
    <script src="plugins/counto/counTo.js"></script>
    <!-- AOS Animation -->
    <script src="plugins/aos/aos.js"></script>
    
    <script src="js/script.js"></script>
    <script src="js/ajax-contact.js"></script>
    
    
   <script>
        $('.ti-angle-left').addClass('fa-solid fa-chevron-left')
        $('.ti-angle-left').removeClass('ti-angle-left')
        
        $('.ti-angle-right').addClass('fa-solid fa-chevron-right')
        $('.ti-angle-right').removeClass('ti-angle-right')
        
        // Get the current year
        const currentYear = new Date().getFullYear();
        
        // Select the element with the ID "current-year"
        const currentYearElement = document.getElementById("current-year");
        
        // Set the innerText of the element to the current year
        currentYearElement.innerText = currentYear.toString();
        
   </script>
    
  </body>
  </html>
   